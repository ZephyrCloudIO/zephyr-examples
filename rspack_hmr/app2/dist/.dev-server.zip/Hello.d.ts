export * from './compiled-types/Hello';
export { default } from './compiled-types/Hello';