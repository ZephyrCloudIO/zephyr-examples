interface Props {
    name: string;
}
export declare const Hello: ({ name }: Props) => import("react/jsx-runtime").JSX.Element;
export {};
