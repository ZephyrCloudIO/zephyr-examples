export default function pi(): number;
